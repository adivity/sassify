const express = require('express')
const router = express.Router()
const fs = require('fs')
const routesPath = `${__dirname}/`
const { removeExtensionFromFile } = require('../middleware/utils')
const {OperationHelper} = require('apac');

/*
 * Load routes statically and/or dynamically
 */

// Load Auth route
router.use('/', require('./auth'))

// Loop routes path and loads every file as a route except this file and Auth route
fs.readdirSync(routesPath).filter(file => {
  // Take filename and remove last part (extension)
  const routeFile = removeExtensionFromFile(file)
  // Prevents loading of this file and auth file
  return routeFile !== 'index' && routeFile !== 'auth'
    ? router.use(`/${routeFile}`, require(`./${routeFile}`))
    : ''
})

/*
 * Setup routes for index
 */
router.get('/', (req, res) => {
  res.render('index')
})

router.get('/hello', (req, res) =>{
  const opHelper = new OperationHelper({
    awsId:     'AKIAI4FFAKHVKDFTQHJA',
    awsSecret: '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',
    assocId:   '83nmnhdsa-20',
    maxRequestsPerSecond: 1
  });

  opHelper.execute('ItemSearch', {
    'SearchIndex': 'Books',
    'Keywords': 'harry potter',
    'ResponseGroup': 'ItemAttributes,Offers',
    locale:    'US'
  }).then((response) => {
    // res.send(response.result)
    res.send(response.responseBody)

  }).catch((err) => {
    console.error("Something went wrong! ", err);
  });

});

/*
 * Handle 404 error
 */
router.use('*', (req, res) => {
  res.status(404).json({
    errors: {
      msg: 'URL_NOT_FOUND'
    }
  })
})

module.exports = router
